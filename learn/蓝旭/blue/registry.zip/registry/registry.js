window.onload=function(){
var box=document.getElementsByClassName('box');
box[0].onclick=function(){
    if(box[0].value=='请输入用户名')
    box[0].value='';
}
box[1].onclick=function(){
    if(box[1].value=='请输入密码'){
         box[1].value='';
    }
   
}
box[2].onclick=function(){
    if(box[2].value=='请确认密码')
    box[2].value='';
}
box[3].onclick=function(){
    if(box[3].value=='请输入手机号')
    box[3].value='';
}
box[4].onclick=function(){
    if(box[4].value=='请输入验证码')
       box[4].value='';
}
box[0].onblur=function(){
    if(box[0].value=='')
    box[0].value='请输入用户名';
}
box[1].onblur=function(){
    if(box[1].value=='')
    box[1].value='请输入密码';
}
box[2].onblur=function(){
    if(box[2].value=='')
    box[2].value='请确认密码';
}
box[3].onblur=function(){
    if(box[3].value=='')
    box[3].value='请输入手机号';
}
box[4].onblur=function(){
    if(box[4].value=='')
    box[4].value='请输入验证码';
}
var btn=document.getElementById("sent");
var x=60;
btn.addEventListener('click',function(){
    var time=setInterval(function(){
        btn.disabled=true;
        btn.value=x+'s';
        if(x==0){
        clearInterval(time);
        btn.disabled=false;
        btn.value='发送验证码';
        x=10;
    }
    x--;
    },1000)   
})
var reg=/[^A-Z]/;
function checkName(){
    if(reg.exec(box[0].value))
        alert('用户名应以大写字母开头');
}
box[0].addEventListener("blur",checkName);
function checkPass(){
    if(/(?=.*[0-9])(?=.*[A-Z])|(?=.*[0-9])(?=.*[a-z])|(?=.*[a-z])(?=.*[A-Z])^[0-9a-zA-Z]{6,12}$/.exec(box[1].value)){
    }
    else
    alert("密码应长度为6-12位，有数字、小写字符和大写字符组成");
}
box[1].addEventListener("blur",checkPass);
box[2].addEventListener('blur',function(){
    if(box[2].value!=box[1].value){
        alert('两次密码输入不同,请重新输入');
    }
})
function checkNum(){
    if(/^1[3-9]\d{9}/.exec(box[3].value)){
    }
    else{
        alert('手机号码不正确');
    }
}
box[3].addEventListener('blur',checkNum);
}